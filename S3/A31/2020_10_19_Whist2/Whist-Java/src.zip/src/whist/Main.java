package whist;

import template.Whist;

public class Main {

	public static void main(String[] args) {

		Whist w = new Whist( new String[]{"Charles","Lando","Daniel","Max"} );
	}

}
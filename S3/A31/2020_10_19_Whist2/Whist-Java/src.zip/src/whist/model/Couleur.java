package whist.model;

/**
 * Modélise la "couleur" d'une carte à jouer.
 */
public enum Couleur {

	PIQUE,

	COEUR,

	CARREAU,

	TREFLE;
};

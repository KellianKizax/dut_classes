package whist.model;

public interface MethodeDeDecompteDesPoints {
	
	public int getPoints( Pli [] plis, Couleur atout );

}

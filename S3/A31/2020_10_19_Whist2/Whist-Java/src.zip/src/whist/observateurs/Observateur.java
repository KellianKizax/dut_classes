package whist.observateurs;

public interface Observateur {
	
	public void mettreAJour();

}

#ifndef __CONFIG_H__
#define __CONFIG_H__

// longueur du code à découvrir
#define CODE_LENGTH 5

// constantes 
static const int CODE_FOUND     = 1;
static const int CODE_NOT_FOUND = 0;

#endif
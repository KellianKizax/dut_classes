import java.awt.*;

public class Segment extends Figure {

    private double longueur;

    public Segment(Vecteur position, Angle orientation, double longueur, Color couleur, int epaisseurTrait) {
        super(position, orientation, couleur, epaisseurTrait);
        this.longueur = longueur;
    }

    public Segment(Vecteur position, Angle orientation, double longueur) {
        super(position, orientation);
        this.longueur = longueur;
    }

    public Segment(Vecteur position, double longueur) {
        super(position);
        this.longueur = longueur;
    }

    public Vecteur getOrigine(){
        return this.getPosition();
    }

    public Vecteur getExtremite(){
        Vecteur pos = this.getOrigine();
        Vecteur bis = new Vecteur(this.longueur, this.getOrientation());
        return pos.ajouter(bis);
    }

    @Override
    public void dessiner(Graphics2D g) {
        Vecteur origine = this.getOrigine();
        Vecteur extremite = this.getExtremite();
        g.drawLine((int)origine.getX(), (int)origine.getY(), (int)extremite.getX(), (int)extremite.getY());
    }

    @Override
    public void redimensionner(double facteur) {
        this.longueur = this.longueur * facteur;
    }

    @Override
    public Figure copier() {
        return new Segment(this.getPosition(), this.getOrientation(), this.longueur, this.getCouleurTrait(), this.getEpaisseurTrait());
    }

    @Override
    public String toString() {
        Vecteur origine = this.getOrigine();
        Vecteur extremite = this.getExtremite();
        return "Segment d'origine x:" + origine.getX() + " y:" + origine.getY() + " et d'extremite x:"
                + extremite.getX() + " y:" + extremite.getY();
    }



}

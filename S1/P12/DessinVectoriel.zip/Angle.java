public class Angle {

    // mesure en radian
    private double mesure;
    public final static Angle NUL = Angle.degres(0);
    public final static Angle DROIT = Angle.degres(90);
    public final static Angle PLAT = Angle.degres(180);

    /**
     * Creer un <i>Angle</i> a�partir d'une mesure donnee en radians.
     * @param rad Angle en radians
     */
    private Angle(double rad){
        this.mesure = rad % (Math.PI * 2);
    }

    /**
     * Creer un nouvel <i>Angle</i> a� partir d'une mesure donnee en degres.
     * @param deg Angle en degres
     * @return <i>Angle</i>
     */
    public static Angle degres(double deg){
        return new Angle(deg*0.01745329252);
    }

    /**
     * Creer un nouvel <i>Angle</i> à partir d'une mesure donnee en radians.
     * @param rad Angle en radians
     * @return <i>Angle</i>
     */
    public static Angle radians(double rad){
        return new Angle(rad);
    }

    /**
     * Donne la mesure de l'<i>Angle</i> en degres
     * @return Angle en degres
     */
    public double getDegres(){
        return (this.mesure/0.01745329252);
    }

    /**
     * Donne la mesure de l'<i>Angle</i> en radians.
     * @return Angle en radians
     */
    public double getRadians(){
        return this.mesure;
    }

    /**
     * Donne un nouvel <i>Angle</i> dont la mesure est egal a la mesure
     * de l'<i>Angle</i> actuel et de l'angle en degres donnee en parametre.
     * @param deg Angle en degres
     * @return <i>Angle</i>
     */
    public Angle ajouterDegres(double deg){
        return new Angle(this.getRadians() + (deg*0.01745329252));
    }

    /**
     * Donne un nouvel <i>Angle</i> dont la mesure est egal a�la mesure
     * de l'<i>Angle</i> actuel et de l'angle en radians donnee en parametre.
     * @param rad Angle en radians
     * @return <i>Angle</i>
     */
    public Angle ajouterRadians(double rad){
        return new Angle(this.getRadians() + rad);
    }

    /**
     * Donne un nouvel <i>Angle</i> dont la mesure est egal a�la somme
     * de la mesure de l'<i>Angle</i> actuel et l'<i>Angle</i> donnee en parametre.
     * @param theta <i>Angle</i>
     * @return <i>Angle</i>
     */
    public Angle ajouter(Angle theta){
        return new Angle(this.getRadians() + theta.getRadians());
    }

    /**
     * Donne le sinus de l'<i>Angle</i> actuel.
     * @return Sinus
     */
    public double sin(){
        return Math.sin(this.mesure);
    }

    /**
     * Donne le cosinus de l'<i>Angle</i> actuel.
     * @return cosinus
     */
    public double cos(){
        return Math.cos(this.mesure);
    }

    /**
     * Donne un nouvel <i>Angle</i> obtenu a partir de coordonees.
     * @param dX coordonnée X
     * @param dY coordonée Y
     * @return <i>Angle</i>
     */
    public static Angle atan(double dX, double dY){
        return new Angle(Math.atan2(dY, dX));
    }

    /**
     * Donne une chaine de charactere sur l'<i>Angle</i> actuel.
     * @return "Angle de mesure x rad"
     */
    public String toString(){
        return "Angle de mesure " + this.mesure + "rad";
    }
}

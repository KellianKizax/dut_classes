import java.awt.*;

public abstract class Figure {

    private int epaisseurTraitParDefaut = 1;
    private Color couleurTraitParDefaut = Color.BLACK;
    private Angle orientationParDefaut = Angle.NUL;

    private int epaisseurTrait = epaisseurTraitParDefaut;
    private Color couleurTrait = couleurTraitParDefaut;
    private Angle orientation = orientationParDefaut;
    private Vecteur position;

    public  Figure(Vecteur position, Angle orientation, Color couleur, int epaisseurTrait){
        this.epaisseurTrait = epaisseurTrait;
        this.couleurTrait = couleur;
        this.orientation = orientation;
        this.position = position;
    }

    public Figure(Vecteur position, Angle orientation){
        this.orientation = orientation;
        this.position = position;
    }

    public Figure(Vecteur position){
        this.position = position;
    }

    public void setCouleurTrait(Color couleur){
        this.couleurTrait = couleur;
    }

    public Color getCouleurTrait() {
        return couleurTrait;
    }

    public void setEpaisseurTrait(int epaisseurTrait){
        this.epaisseurTrait = epaisseurTrait;
    }

    public int getEpaisseurTrait(){
        return this.epaisseurTrait;
    }

    public void setPosition(Vecteur position){
        this.position = position;
    }

    public Vecteur getPosition(){
        return this.position;
    }

    public void setOrientation( Angle orientation){
        this.orientation = orientation;
    }

    public Angle getOrientation(){
        return this.orientation;
    }

    abstract public void dessiner(Graphics2D g);

    abstract public Figure copier();

    abstract public String toString();

    public void deplacer(double dX, double dY){
        Vecteur deplacement = new Vecteur(dX, dY);
        this.setPosition( this.getPosition().ajouter(deplacement) );
    }

    // en radians
    public void tourner(double angle){
        Angle tourner = Angle.radians(angle);
        this.setOrientation( this.getOrientation().ajouter(tourner) );
    }

    public void tournerAutour(Vecteur centre, Angle angle){
        
    }

    abstract public void redimensionner(double facteur);

    boolean initTrait(Graphics2D g){
        boolean res = false;
        if(this.getEpaisseurTrait()>=0){
            res = true;
            g.setStroke(new BasicStroke(this.getEpaisseurTrait()));
        }
        return res;
    }

    public final Angle getOrientationParDefaut() {
        return orientationParDefaut;
    }

    public final void setOrientationParDefaut(Angle orientationParDefaut){
        this.orientationParDefaut = orientationParDefaut;
    }

    public final int getEpaisseurTraitParDefaut(){
        return epaisseurTraitParDefaut;
    }

    public final void setEpaisseurTraitParDefaut(int epaisseurTraitParDefaut){
        this.epaisseurTraitParDefaut = epaisseurTraitParDefaut;
    }

    public final Color getCouleurTraitParDefaut(){
        return couleurTraitParDefaut;
    }

    public final void setCouleurTraitParDefaut(Color couleurTraitParDefaut){
        this.couleurTraitParDefaut = couleurTraitParDefaut;
    }

}

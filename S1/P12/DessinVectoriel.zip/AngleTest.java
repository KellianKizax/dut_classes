import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class AngleTest {
	
	Angle agl;

    @Test
    void setUp() 
    {
        // 0.785398 rad ~ 44,999990638�
        agl = Angle.radians(0.785398);
    }

    @Test
    void degres()
    {
        Angle.degres(90);
    }

    @Test
    void radians() 
    {
        Angle.radians(Math.PI);
    }

    @Test
    void getDegres() 
    {
        agl = Angle.degres(55);
        assertEquals(55, agl.getDegres(), 1);
    }

    @Test
    void getRadians() 
    {
        agl = Angle.radians(0.900000);
        assertEquals(0.900000, agl.getRadians(), 0.000001);
    }

    @Test
    void ajouterDegres() {
        agl = Angle.degres(45);
        assertEquals(Angle.degres(90).getDegres(), agl.ajouterDegres(45).getDegres(), 1);
    }

	@Test
	void testAjouter() 
	{
		Angle a1;
		Angle a2;
		Angle res;

		a1 = Angle.degres(10);
		a2 = Angle.degres(5);
		res = Angle.degres(15);
		a2 = a1.ajouter(a2);
		assertEquals(a2.getRadians(),res.getRadians());
	}

	@Test
	void testSin() 
	{
		double rep = 0.8414709848;
		double met = Angle.radians(1).sin();;
		assertEquals(rep,met,0.01);
	}

	@Test
	void testCos() 
	{
		double rep = 0.54030230586;
		double met = Angle.radians(1).cos();
		assertEquals(rep,met,0.01);
	}

	@Test
	void testToString() 
	{
		String rep = "Angle de mesure 1.0rad";
		String met = Angle.radians(1).toString();
		assertEquals(rep,met);
	}

}

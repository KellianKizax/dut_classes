import java.awt.Color;
import java.awt.Graphics2D;

public class Rectangle extends Surface {

	double longeur =0;
	double largeur = 0;
	
	public Rectangle(Vecteur position, double longu, double larg)
	{
		super(position);
		this.longeur = longu;
		this.largeur = larg;
	}
	
	public Rectangle(Vecteur position, Angle orientation, double longu, double larg)
	{
		super(position,orientation);
		this.longeur = longu;
		this.largeur = larg;
	}
	
	public Rectangle(Vecteur position, Angle orientation, double longu, double larg, Color couleurTrait, int epaisseurTrait, Color couleurRemplissage)
	{
		super(position, orientation, couleurTrait, epaisseurTrait, couleurRemplissage);
		this.longeur = longu;
		this.largeur = larg;
	} 
	
	public double surface() {
		return getLongeur() * getLargeur();
	}
	
	public double perimetre() {
		return (getLongeur() * 2) + (getLargeur() * 2);
	}

	public double getLongeur() {
		return longeur;
	}

	public double getLargeur() {
		return largeur;
	}

	public double getSommets() {
		return this.getPosition().getX() + this.getPosition().getY();
	}

	@Override
	public void dessiner(Graphics2D g) {
		Vecteur pos = this.getPosition();
		int longu = (int)this.getLongeur();
		int larg = (int)this.getLargeur();
		g.drawRect((int)pos.getX(), (int)pos.getY(), longu, larg);
	}

	@Override
	public Rectangle copier() {
		return new Rectangle(this.getPosition(), this.getOrientation(), this.getLongeur(), this.getLargeur(), this.getCouleurTrait(), this.getEpaisseurTrait(), this.getCouleurRemplissage());
	}

	@Override
	public String toString() {
		return "Rectangle de position x: " + this.getPosition().getX() + " y: " + this.getPosition().getY() + " de longeur: " + this.getLongeur() + " et de largeur: " + this.getLargeur();
	}

	@Override
	public void redimensionner(double facteur) {
		this.largeur = this.getLargeur() * facteur;
		this.longeur = this.getLongeur() * facteur;
	}
}

import java.awt.*;

public abstract class Surface extends Figure {
	
	private final Color couleurRemplissageParDefault = null;
	private Color couleurRemplissage = couleurRemplissageParDefault;
	
	public Surface(Vecteur position)
	{
		super(position);
	}
	
	public Surface(Vecteur position, Angle orientation) 
	{
		super(position, orientation);
	}
	
	public Surface(Vecteur position, Angle orientation, Color couleur, int epaisseurTrait, Color couleurRemplissage ) {
		super(position, orientation, couleur, epaisseurTrait);
		this.couleurRemplissage = couleurRemplissage;
	}

	public Color getCouleurRemplissage() {
		return couleurRemplissage;
	}

	public void setCouleurRemplissage(Color couleurRemplissage) {
		this.couleurRemplissage = couleurRemplissage;
	}

	public Color getCouleurRemplissageParDefault() {
		return couleurRemplissageParDefault;
	}
	
	public Color setCouleurRemplissageParDefault( Color couleurRemplissageParDefault) {
		return couleurRemplissageParDefault;
	}
	
	public abstract double surface();
	
	public abstract double perimetre();

	boolean initRemplissage(Graphics2D g){
		boolean res = false;
		if(this.getCouleurRemplissage() != null){
			res = true;
			g.setPaint(this.getCouleurRemplissage());
		}

		return res;
	}
}

import java.awt.Color;
import java.awt.Graphics2D;

public class Cercle extends Surface {
	
	private double rayon = 0;

	public Cercle(Vecteur position, double r) {
		super(position);
		this.rayon = r;
	}
	
	public Cercle(Vecteur position, Angle orientation, double r, Color couleur, int epaisseurTrait, Color couleurRemplissage) {
		super(position, orientation, couleur, epaisseurTrait, couleurRemplissage);
		this.rayon = r;
	}
	
	public Vecteur getCentre() {
		return this.getPosition();
	}
	
	public double getRayon() {
		return this.rayon;
	}
	
	public double getDiametre() {
		return this.rayon*2;
	}
	
	@Override
	public double surface() {
		return Math.PI * this.getRayon() * this.getRayon();
	}
	
	@Override
	public double perimetre() {
		return 2 * Math.PI * this.getRayon();
	}
	
	@Override
	public void dessiner(Graphics2D g) {
		Vecteur pos = this.getPosition();
		int diam = (int)this.getDiametre();
		g.drawOval((int)pos.getX(), (int)pos.getY(), diam, diam);
	}
	
	@Override
	public Cercle copier() {
		return new Cercle(this.getPosition(), this.getOrientation(), this.getRayon(), this.getCouleurTrait(), this.getEpaisseurTrait(), this.getCouleurRemplissage());
	}
	
	@Override
	public String toString() {
		return "Cercle de position x: " + this.getPosition().getX() + " y: " + this.getPosition().getY() + " de rayon r: " + this.getRayon();
	}

	@Override
	public void redimensionner(double facteur) {
		this.rayon = this.getRayon() * facteur;
	}
}

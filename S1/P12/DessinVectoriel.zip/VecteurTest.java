import org.junit.jupiter.api.Test;

import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.*;

class VecteurTest {

    Vecteur v = new Vecteur(1,2);

    @Test
    void setUp(){
        v = new Vecteur(1, 2);
    }

    @Test
    void testConstructeur1_null() {

        try {
            new Vecteur(1,null);
            fail("Le contructeur accepte un paramètre null");
        } catch (NullPointerException ex) {
            //Ok
        } catch (Exception ex) {
            fail("Le contructeur lance " + ex + "pour un paramètre null");
        }
    }

    @Test
    void testConstructeur2_null() {

        try {
            new Vecteur(2,null);
            fail("Le contructeur accepte un paramètre null");
        } catch (NullPointerException ex) {
            //Ok
        } catch (Exception ex) {
            fail("Le contructeur lance " + ex + "pour un paramètre null");
        }
    }

    @Test
    void getX() {
        assertEquals(1,v.getX(), 0.1);
    }

    @Test
    void getY() {
        assertEquals(2,v.getY());
    }

    @Test
    void ajouter() {
        Vecteur u = new Vecteur(2,1);
        assertEquals(3, v.ajouter(u).getX());
        assertEquals(3,v.ajouter(u).getY());
    }

    @Test
    void oppose() {
        assertEquals(-1, v.oppose().getX());
        assertEquals(-2, v.oppose().getY());
    }

    @Test
    void soustraire() {
        Vecteur u = new Vecteur(2, 1);
        assertEquals(-1,v.soustraire(u).getX());
        assertEquals(1,v.soustraire(u).getY());
    }

    @Test
    void multiplier() {
        assertEquals(2,v.multiplier(2).getX());
        assertEquals(4,v.multiplier(2).getY());
    }

    @Test
    void longueur() {
        double longueur = Math.sqrt(Math.pow(2, v.getX()) + Math.pow(2, v.getY()));
        assertEquals(longueur, v.longueur(), 0.1);
    }

    @Test
    void orientation() {
        Angle a = Angle.degres(45);
        Vecteur u = new Vecteur(2,a);
        assertEquals(a.getDegres(), u.orientation().getDegres(), 0.1);
    }

    @Test
    void testToString() {
        String temp = "Vecteur de coordonnees x: 1.0 ; y: 2.0";
        assertEquals(temp, v.toString());
    }
}
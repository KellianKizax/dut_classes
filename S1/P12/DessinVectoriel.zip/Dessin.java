import java.awt.Graphics;
import java.time.LocalDate;
import java.util.ArrayList;

public class Dessin {
	
	//Variables globales pour les contructeurs
	String titre;
	String auteur;
	LocalDate dateCreation = LocalDate.now();
	int largeur;
	int hauteur;

	ArrayList<Figure> listFigures = new ArrayList<Figure>();

	//Constructeur de Dessin version 1
	public Dessin(String t, String a, LocalDate dC, int l, int h)
	{
		if (t == null || a == null || t == "" || a == "") {
			throw new IllegalArgumentException();
		}
		else {
			this.titre = t;
			this.auteur = a;
			this.dateCreation = dC;
			this.largeur = l;
			this.hauteur = h;
		}
	}
	
	//Constructeur de Dessin version 2
	public Dessin(String t, String a, int l, int h) 
	{
		if (t == null || a == null || t == "" || a == "") {
			throw new IllegalArgumentException();
		}
		else {
			this.titre = t;
			this.auteur = a;
			this.largeur = l;
			this.hauteur = h;
		}
	}

	public void ajouterFigure(Figure f)
	{
		listFigures.add(f);
	}
	
	public void listerFigures() 
	{
		ArrayList<Figure> list = new ArrayList<Figure>();
		for(int i = 0; i < listFigures.size(); i++) 
		{
			list.add(listFigures.get(i));
		}
	}
	
	/**
	 *Donne le toString d'un dessin en String
     * @return proprietes en String
	 */
	@Override
	public String toString() 
	{
		return this.titre + "  " + this.auteur + "  " + this.dateCreation + "  " + this.largeur + "  " + this.hauteur;
	}

	//La m�thode dessiner n'est pas encore d�finie dans Figures
	public void paint(Graphics g) 
	{
		for(int i = 0; i < listFigures.size(); i++) 
		{
			//listFigures.get(i).dessiner(g);
		}
	}

	public String getTitre() 
	{
		return titre;
	}

	public void setTitre(String titre) 
	{
		this.titre = titre;
	}

	public String getAuteur() 
	{
		return auteur;
	}

	public void setAuteur(String auteur) 
	{
		this.auteur = auteur;
	}

	public LocalDate getDateCreation() 
	{
		return dateCreation;
	}

	public void setDateCreation(LocalDate dateCreation) 
	{
		this.dateCreation = dateCreation;
	}

	public int getLargeur() 
	{
		return largeur;
	}

	public void setLargeur(int largeur) 
	{
		this.largeur = largeur;
	}

	public int getHauteur() 
	{
		return hauteur;
	}

	public void setHauteur(int hauteur) 
	{
		this.hauteur = hauteur;
	}
}

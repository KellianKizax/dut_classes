import static org.junit.Assert.*;

import java.awt.Graphics;
import java.time.LocalDate;
import java.util.ArrayList;

import org.junit.Test;

public class TestDessin {

	Dessin dess;
	
	@Test 
	public void setUp() 
	{
		dess = new Dessin("voile","hugo",LocalDate.parse("2020-05-13"),13,20);
	}
	
	@Test
	public void testConstructeurTitre1() 
	{
		
		try 
		{
			new Dessin("","hugo",LocalDate.parse("2020-05-13"),13,20);
			fail("Le contructeur accepte un titre vide");
		}
		
		catch (IllegalArgumentException ex) 
		{
			//Ok
		}
		
		catch (Exception ex) 
		{
			fail("Le contructeur lance " + ex + "pour un titre vide");
		} 
		
	}
	
	@Test
	public void testConstructeurTitre2() 
	{
		
		try 
		{
			new Dessin(null,"hugo",LocalDate.parse("2020-05-13"),13,20);
			fail("Le contructeur accepte un titre null");
		}
		
		catch (IllegalArgumentException ex) 
		{
			//Ok
		}
		
		catch (Exception ex) 
		{
			fail("Le contructeur lance " + ex + "pour un titre null");
		} 
		
	}
	
	@Test
	public void testConstructeurAuteur1() 
	{
		
		try 
		{
			new Dessin("voile","",LocalDate.parse("2020-05-13"),13,20);
			fail("Le contructeur accepte un auteur vide");
		}
		
		catch (IllegalArgumentException ex) 
		{
			//Ok
		}
		
		catch (Exception ex) 
		{
			fail("Le contructeur lance " + ex + "pour un auteur vide");
		} 
		
	}
	
	@Test
	public void testConstructeurAuteur2() 
	{
		
		try 
		{
			new Dessin("voile",null,LocalDate.parse("2020-05-13"),13,20);
			fail("Le contructeur accepte un auteur null");
		}
		
		catch (IllegalArgumentException ex) 
		{
			//Ok
		}
		
		catch (Exception ex) 
		{
			fail("Le contructeur lance " + ex + "pour un auteur null");
		} 
		
	}
	
	@Test
	public void testAjouterFigure() 
	{
		//On utilise String � la place de Figure (classe non cr��)
		ArrayList<String> listFigures = new ArrayList<String>();
		String fig = new String();
		listFigures.add(fig);
		assertEquals(fig,listFigures.get(listFigures.size()-1));
	}
	
	@Test
	public void testListerFigures() 
	{

	}
	
	@Test
	public void TestToString() 
	{
		dess = new Dessin("voile","hugo",LocalDate.parse("2020-05-13"),13,20);
		String phrase = dess.getTitre() + "  " + dess.getAuteur() + "  " + dess.getDateCreation() + "  " + dess.getLargeur() + "  " + dess.getHauteur();
		assertEquals(phrase,dess.toString());
	}
	
	//M�thode de base incompl�te
	@Test
	public void testPaint() 
	{
		Graphics g = null;
		dess.paint(g);
	}
	
	@Test
	public void testGetTitre() 
	{
		String titre = "voile";
		dess = new Dessin("voile","hugo",LocalDate.parse("2020-05-13"),13,20);
		assertEquals(titre,dess.getTitre());
	}
	
	@Test
	public void testSetTitre() 
	{
		dess = new Dessin("voile","hugo",LocalDate.parse("2020-05-13"),13,20);
		String newTitre = "mat";
		dess.setTitre("mat");
		assertEquals(newTitre,dess.getTitre());
	}
	
	@Test
	public void testGetAuteur() 
	{
		dess = new Dessin("voile","hugo",LocalDate.parse("2020-05-13"),13,20);
		dess = new Dessin("voile","hugo",LocalDate.parse("2020-05-13"),13,20);
		String auteur = "hugo";
		assertEquals(auteur,dess.getAuteur());
	}
	
	@Test
	public void testSetAuteur() 
	{
		dess = new Dessin("voile","hugo",LocalDate.parse("2020-05-13"),13,20);
		String newAuteur = "valentin";
		dess.setAuteur("valentin");
		assertEquals(newAuteur,dess.getAuteur());
	}
	
	@Test
	public void testGetDateCreation() 
	{
		dess = new Dessin("voile","hugo",LocalDate.parse("2020-05-13"),13,20);
		LocalDate date = LocalDate.parse("2020-05-13");
		assertEquals(date,dess.getDateCreation());
	}
	
	@Test
	public void testSetDateCreation() 
	{
		dess = new Dessin("voile","hugo",LocalDate.parse("2020-05-13"),13,20);
		LocalDate newDate = LocalDate.parse("2020-05-14");
		dess.setDateCreation(LocalDate.parse("2020-05-14"));
		assertEquals(newDate,dess.getDateCreation());
	}
	
	@Test
	public void testGetLargeur() 
	{
		int largeur = 13;
		dess = new Dessin("voile","hugo",LocalDate.parse("2020-05-13"),13,20);
		assertEquals(largeur,dess.getLargeur());
	}
	
	@Test
	public void testSetLargeur() 
	{
		int newLarg = 23;
		dess = new Dessin("voile","hugo",LocalDate.parse("2020-05-13"),13,20);
		dess.setLargeur(23);
		assertEquals(newLarg,dess.getLargeur());
	}
	
	@Test
	public void testGetHauteur() 
	{
		int hauteur = 20;
		dess = new Dessin("voile","hugo",LocalDate.parse("2020-05-13"),13,20);
		assertEquals(hauteur,dess.getHauteur());
	}
	
	@Test
	public void testSetHauteur() 
	{
		int newHaut = 30;
		dess = new Dessin("voile","hugo",LocalDate.parse("2020-05-13"),13,20);
		dess.setHauteur(30);
		assertEquals(newHaut,dess.getHauteur());
	}

}

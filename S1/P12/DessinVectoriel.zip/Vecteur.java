public class Vecteur {

    private double x;
    private double y;

    public Vecteur(double x, double y){
        this.x = x;
        this.y = y;
    }

    public Vecteur(double rayon, Angle orientation){
        double adjacent = rayon / orientation.cos();
        double oppose = rayon / orientation.sin();
        this.x = adjacent;
        this.y = oppose;
    }

    public double getX(){
        return this.x;
    }

    public double getY(){
        return this.y;
    }

    public Vecteur ajouter(Vecteur autre){
        double x = this.getX() + autre.getX();
        double y = this.getY() + autre.getY();
        return new Vecteur(x, y);
    }

    public Vecteur oppose(){
        double x = 0 - this.getX();
        double y = 0 - this.getY();
        return new Vecteur(x, y);
    }

    public Vecteur soustraire(Vecteur autre){
        double x = this.getX() - autre.getX();
        double y = this.getY() - autre.getY();
        return new Vecteur(x, y);
    }

    public Vecteur multiplier(double facteur){
        double x = facteur * this.getX();
        double y = facteur * this.getY();
        return new Vecteur(x, y);
    }

    public double longueur(){
        double longueur = Math.pow(2, this.getX()) + Math.pow(2, this.getY());
        return Math.sqrt(longueur);
    }

    public Angle orientation(){
        return Angle.atan(this.getX(), this.getY());
    }

    public String toString(){
        return "Vecteur de coordonnees x: " + this.getX() + " ; y: " + this.getY();
    }
}

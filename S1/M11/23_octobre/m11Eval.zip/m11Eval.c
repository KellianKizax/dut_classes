#include <stdio.h>
#include "m11Eval.h"

unsigned long quotient(unsigned long a, unsigned long b) {
    //Coder ici

    return 0;
}

void afficher_division_euclidienne(unsigned long a, unsigned long b) {
    //Coder ici
}



void afficher_diviseurs(long nb) {
    //Coder ici
}

unsigned int nombre_de_diviseurs_positifs(unsigned long nb) {
    //Coder ici
    return 0;
}

char est_premier(unsigned long nb) {
    //Coder ici
    return 0;
}

void afficher_decomposition_facteurs_premiers(unsigned long nb) {
    //Coder ici
}
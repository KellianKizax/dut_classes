#include <stdio.h>
#include "m11Eval.h"

int main(){
    //Testez vos fonctions ici

    return 0;
}
